# kylon-cli

Local runtime CLI for running external agents for a P2 workspace.

No preinstalled Node.js is needed for the hosted install below — a machine
without one gets a private, checksum-verified runtime that only Kylon uses.
Only the `npx` spellings require your own Node.js 22.15.0 or newer.

## Install

For Codex agents, Kylon prefers the CLI bundled with the Codex desktop app.
Desktop app updates are discovered when Kylon next checks or starts Codex,
including on Windows where each update can replace the executable's directory.
If the desktop CLI is absent, Kylon uses the standalone CLI on PATH; setup and
service repair install it with npm when neither is available. An explicitly
selected executable remains unchanged, and desktop copies are updated by the
desktop app rather than by Kylon.

The recommended install is the hosted script (macOS/Linux):

```bash
curl -fsSL https://api.kylon.io/install.sh | sh
```

It installs the pinned CLI bundle under `~/.kylon` (no sudo; a machine
without Node.js gets a private, checksum-verified runtime under
`~/.kylon/runtime` that only Kylon uses), puts `kylon` on your PATH, records
the serving environment as the default `--server-url`, and chains straight
into `kylon login`. Rerunning it is safe: on a machine that already has
Kylon, it verifies the installation and repairs a damaged one before it
updates it. Non-production deployments serve
the same script from their own API origin (for example
`https://api.purework.ai/install.sh` installs `@next` and logs into dev).
`KYLON_INSTALL_NO_LOGIN=1` installs without starting the login;
`KYLON_INSTALL_NO_MODIFY_PATH=1` leaves shell profiles untouched.

The CLI is also published to npm as
[`kylon-cli`](https://www.npmjs.com/package/kylon-cli). The Web UI provides
two distinct copy-paste entry points:

- **Settings → Developer tools → Kylon CLI** shows the hosted install
  one-liner above; installing chains straight into the browser sign-in, and
  on an installed machine `kylon login` with no flags does the same and lets
  the browser approval page choose the workspace. An **Advanced** expander
  keeps the setup-token and `npx --yes kylon-cli@<tag> auth login` fallbacks
  for machines that cannot run the script. Its **Use with Your Agents**
  prompt teaches Claude Code, Codex, Grok Build, Hermes, or OpenClaw to discover and use
  `kylon workspace` commands without assuming a provider-specific interface.
- **An external agent's Profile** shows
  `npx --yes kylon-cli@<version> agent link --url '<one-time link>'`. Custom
  ACP agents append `-- <launch command> [args]` to that same line. The link
  embeds a short-lived credential, so the CLI does not open a browser or reuse
  a human workspace credential. It checks that the selected Claude Code or
  Codex CLI is installed and authenticated, shows the exact agent and
  workspace for confirmation, connects the agent, and starts its local
  runtime. For ACP, the same operation also saves the selected launch command.
  The credential expires after 30 minutes and can be redeemed only once;
  rerunning the same installation's interrupted redemption is idempotent.
  Because the link carries the credential, treat the command as a secret until
  it is used or expires.

A local runtime may be connected with one Kylon server and workspace at a time.
Equivalent spellings of the same server (`https://dev.purework.ai/api` and
`https://api.purework.ai`, `https://app.kylon.io/api` and
`https://api.kylon.io`) count as the same registration; preview environments
never do, even though they serve the same workspace ids as dev. Run
`kylon disconnect` before connecting it somewhere else. This forgets only the
local runtime registration; it revokes nothing or changes any workspace-side
agent configuration.

`kylon login` (alias `auth login`) browser-authenticates the human operator for
`kylon workspace` commands. `--workspace <id>` pins the workspace up front;
without it the browser approval page asks the user to choose one, defaulting to
the workspace they most recently worked in. The default API server resolves
from `--server-url`, then the server env vars, then the URL recorded by the
hosted install script in `~/.kylon/server-url`, then production.
`agent link` authenticates only the link operation with its embedded
credential; it never creates a human CLI session. Claude Code linking checks the
existing installation and authentication without installing or updating Claude,
including desktop onboarding. Use `kylon provider update claude-code` to request
an update explicitly. Linking mints or reuses an
installation credential stored locally with mode `0600` and starts the local
agent runtime. In release builds a user-level service is installed so the
daemon survives terminal exit, reboot, and sleep/wake: `launchd` on macOS,
`systemd --user` on Linux, and on Windows a logon-triggered Scheduled Task
named `Kylon Gateway` that runs `kylon gateway supervise`, a small loop that
restarts `gateway run` after a crash and after a drained upgrade. When no
service can be installed (a source build, or a Windows machine whose policy
blocks scheduled tasks) the daemon runs in the foreground until `Ctrl+C`, and
`connect` says so.

### Connecting with a setup command: `kylon connect --intent computer`

The Kylon app connects this computer through the installed CLI, without a
browser and without signing anyone in:

```bash
kylon connect --setup-token <token> --workspace <id> --server-url <url> --intent computer --attempt <id> --json
```

The setup token (single use, 30 minutes, minted for one workspace) is the
approval: the CLI starts a device authorization with `intent: "computer"`,
receives this computer's key, writes the registration, and installs and starts
the gateway service as `kylon connect` does (`--no-start` registers only). It
writes no human credential: `workspace-auth.json` is never read or written, so
`kylon workspace` commands still need `kylon login`. `--setup-token`,
`--workspace` and an explicit `--server-url` are all required (the production
default never applies), and `--attempt` names the app's attempt (a standalone
run mints one).

Nothing is spent before the checks pass: a registration of another server
refuses with the usual "already connected to a different server" message, and
a registration of another workspace refuses with `computer_in_other_workspace`
until `kylon disconnect` clears it. A registration of this workspace only runs
the service step. An enrollment in flight is recorded in
`desktop-onboarding/enrollment-<digest>.json` (mode 0600; the request's
capability and the key's fingerprint, never the key) before the request is
sent, so a run that stopped part way is finished by the next one: it asks the
server again and commits the same key, or cancels what is owed first.

With `--json`, stdout carries exactly one document,
`{ ok, workspace_id, computer_id, install_id, connected_at, credential_id, created, attempt_id, generation, service, placement }`,
and progress goes to stderr. A failure is `{ ok: false, kind: "error", code,
text, details }` with `details.retryable`, for example `setup_token_rejected`
(generate a new setup command), `computer_intent_unsupported` (the server
predates this form), `enrollment_in_progress`, or `enrollment_poll_exhausted`
(run the same command again to pick up where it left off); an argument error
of these forms (a flag without its value included) is the same document with
`missing_required_argument` or `invalid_arguments` and exit code 2. A request
the server ends (`denied`, or `expired` past its re-delivery window) is
cancelled on the server before a new one starts, since its key may already
have been delivered.

`kylon connect --cancel --attempt <id> --json` cancels that attempt's pending
connection: it settles the request on the server the record names (whatever
this installation is registered with meanwhile, and without touching that
registration or its service), or keeps a connection the attempt had already
completed and revokes nothing. Its answer is
`{ ok, outcome, generation, request_id?, destroyed? }`, where `outcome` is
`cancelled`, `committed`, `sealed_only` (another attempt has taken the
connection over; nothing changed), `no_journal`, or `incomplete` (Kylon could
not be reached, or this computer's saved connection could not be read while a
delivered key may be in it, `reason: "registration_unreadable"`; the same
command finishes it). Its failure reports go to the record's server only,
never to the default one.

### `kylon onboard`

`kylon onboard` is the terminal-first way to start: it creates a **new**
workspace from the Claude Code or Codex context already on this machine. Run it
from your project directory, or install and onboard in one line:

```bash
curl -fsSL https://api.kylon.io/install.sh | sh -s -- onboard
```

The installer hands `kylon onboard` the controlling terminal for local selection
and confirmation; on a machine without one (CI, a headless box) it passes `--yes` and
the browser confirmation is the only gate.

All detected providers are selected by default. When both Claude Code and
Codex are present, the interactive selector starts with both checked; deselect
either one by number, then press Enter. At least one must remain selected.
Non-interactive runs (`--yes`, `--json`, or a headless installer) also select
all detected providers. Use `--provider claude-code|codex|all` to override
selection explicitly, including when detection finds no context.
`--main-provider claude-code|codex` designates the main agent and must name a
selected provider; otherwise the first selected provider is main. When neither
provider is detected and there is no override, Claude Code remains the fallback.

The agent picker shows both providers with read-only readiness: ready, sign-in
required, not installed, unable to run, or unverified. Readiness does not install
software or start sign-in. An unusable binary without setup files is shown but
not selected by default; explicit provider overrides still apply. Selected providers pass their normal authentication
check before context upload; scripted runs do not open an interactive sign-in.

The project picker combines Claude Code project/session metadata and Codex
project configuration/session metadata. The current project starts selected;
other discovered projects start unchecked. Toggle projects by number or use
`a <path>` to add a folder. At least one and at most eight projects can be
selected. Stale folders, symlinked metadata and malformed records are skipped;
large inventories are bounded, with explicit paths available for omitted folders.
Discovery reads project metadata; content imports read only selected folders and
the provider-global files described below. Paths remain local; the server receives
opaque project IDs and display names.

In scripted runs, use repeated `--project <path>` arguments to select projects.
Relative paths resolve from `--cwd`. Without `--project`, only the current project
is imported. Explicit paths bypass discovery. Aliases of the same working directory are
deduplicated. Different working directories in one repository are rejected so
a scripted run cannot silently lose one folder’s nested instructions.
`--project-name` applies only when one project is selected.

The browser shows the selected agent count, lets you deselect either provider,
choose the main agent, and edit each agent's name, avatar and imports separately.
Review imports by selecting a project (or Global context) and an agent. Removing
a project excludes its persona sources, skills, memory and suggested Room;
provider-global imports remain independently selectable. Import edits survive
switching projects or agents and deselecting/reselecting either. Both agents join
the selected Rooms. Same-named imported skills from different
providers or projects are stored separately, with provider- and project-qualified workspace slugs.
`--agent-name` is for single-provider runs; team names are edited in the browser.

```bash
kylon onboard --yes --provider all --main-provider codex --project ./api --project ../web
kylon onboard --yes --json --provider claude-code --no-start
```

Codex global memory remains opt-in through `--include-memory`, including when
both providers are selected. Each provider must pass its own authentication
check. If only one connection succeeds after workspace creation, the CLI keeps
that connection and its recovery record. Run `kylon onboard` again to connect
only the remaining agent to the same workspace; it does not create another
workspace or restart completed connections. The shared runtime starts once
all selected connections are saved (unless `--no-start` is set).

It detects, offline and read-only, the project (the nearest `.git` ancestor,
named from its `origin` repository when available and otherwise from its
directory), the instruction files, and the skill packages each agent loads.

For **Claude Code** that is the `CLAUDE.md` instruction files (project,
`.claude/`, and user-level), the user's Claude Code skill directory, the
project's memory entries, and direct child skill packages under these exact
repository locations:

- `.claude/skills`
- `.agents/skills`
- `.github/skills`
- `agent_resources/skills`
- `skills`

For **Codex** it is `AGENTS.md`, walked the way Codex walks it:
`$CODEX_HOME/AGENTS.md` first, then one file in **every** directory from the
repository root down to the working directory, deepest last, because that is
the order Codex applies them in and the order the persona is joined in. Its
skills come from `.agents/skills` in every directory from the working directory
up to the repository root, plus `$CODEX_HOME/skills` and `$HOME/.agents/skills`;
the nearest directory wins a name contest, and Codex's own `.system` built-ins
are left alone. `AGENTS.override.md` is never uploaded, for the same reason
`CLAUDE.local.md` is not: Codex documents it as a temporary machine-local
override, removed to restore the shared guidance, so it is one machine's
private amendment rather than the instruction set a workspace should inherit.
When the instruction chain is longer than the five-file cap, the global layer,
the repository root, and the directories nearest the working directory are kept
and the dropped middle is reported. There is a length budget as well as a file
count: the agent's instructions are held to a character limit that the server
applies by trimming the *end* of the joined text, which for Codex is the most
specific layer. So when the combined files are too long, the broadest ones are
dropped here instead — and named — so the instructions closest to your working
directory are the ones that survive.

Each skill package must be a direct child directory with a top-level
`SKILL.md`. Discovery checks only the listed roots; it does not recursively
search the repository for directories named `skills`. Roots are processed in
the listed order, duplicate package names keep the first match, and an
unusually large root is skipped before any packages inside it are read.

Codex memory is **not** uploaded unless you pass `--include-memory`. Claude
Code keeps memory per project, so onboarding one project uploads only that
project's entries; Codex keeps a single store under `$CODEX_HOME/memories`
covering every repository the machine has worked on, and sending all of it to a
new workspace is a choice rather than a detail. With the flag, the entries and
the compact `memory_summary.md` are uploaded; the `MEMORY.md` routing index and
Codex's derived working state (`raw_memories.md`, `rollout_summaries/`) are not.

Env files, credential-shaped content, binaries, empty files, oversized files,
and symlinks are never uploaded. Its terminal summary shows the semantic
project name and its source separately from the physical checkout root. It then
asks once (Enter confirms) and opens your browser: you sign in or sign up,
review the proposal, rename or untick anything, and press one button. The
workspace, its Rooms, and each selected agent with its own persona, skills and
memory are created there; the terminal then connects the selected agents on
this computer and starts the local runtime. Nothing durable exists until you press that button — an
abandoned run leaves only expiring server-side state.

It never attaches to an existing workspace. For that, use `kylon login` and
create the agent in the Web UI.

A computer can currently be connected to one workspace at a time, so `onboard`
refuses when this installation already holds a connection — run
`kylon disconnect` first. It also refuses once this machine holds credentials
for five workspaces on the same server. (The one-connection rule is interim;
multi-workspace binding is a planned change.)

If another onboarding is incomplete, an interactive `kylon onboard` (including
`curl … | sh -s -- onboard`) offers two choices. Use the arrow keys and Enter:

- **Resume existing onboarding** (selected by default): stop the verified previous
  onboarding process if it is still running, reopen its browser confirmation,
  and finish the same setup in this terminal.
- **Overwrite onboarding**: stop the previous run and cancel its pending browser
  request before creating a fresh proposal. Any workspace already created is
  kept, and its CLI credential is saved before replacing the recovery record.
  Overwrite does not delete a workspace or disconnect an already bound agent.

A browser approval already building a workspace cannot be cancelled mid-build;
its recovery state is kept and the terminal explains how to retry. On an older
API without terminal cancellation, Resume remains available and Overwrite keeps
the recovery record. Non-interactive reruns resume a saved request when no other
process owns it; they never silently choose Overwrite. A live owner needs an
interactive rerun (or the explicit `--discard-pending` flag).

If the run is interrupted after the browser has confirmed (a dropped connection,
a provider update that failed, a closed terminal), the workspace exists but the
agent is not yet bound. Run `kylon onboard` again: it finds the resume record it
left in `~/.kylon/onboard-pending.json` (mode `0600`, holding the request's
device code and PKCE verifier) and finishes binding that workspace instead of
creating another. A record the server has since dropped is discarded and the
run starts over, while a record whose workspace was already created is kept with
instructions (`kylon login --workspace <id>`, then connect the agent from its
profile in the browser) until you pass `--discard-pending` to start a different
workspace on purpose. Discarding a request the browser has not answered yet is
refused while it is still open (cancel it on the browser page or wait for it to
expire), because a tab left open on it could still create a workspace this
computer would then have no way to reach; a record that has become unreadable
also stops the run until it is repaired or discarded, and so does a damaged
`computer-session.json`, which is read strictly at the one-connection check. One `kylon onboard` runs per computer at a time (a
second concurrent run is refused up front; a run that was paused for minutes
while another took its place stops rather than continuing), and a resumed run
applies the same one-connection rule as a fresh one. `--json` never starts the
provider's interactive sign-in; a signed-out Claude Code or Codex fails with the
command to run, and stdout stays one JSON document. A workspace credential that cannot be saved locally is revoked
server-side rather than left live.

For agent-driven runs, `--yes` skips the local prompt and `--json` (which
requires `--yes`) prints
`{ ok, server_url, workspace_id, workspace_name, agent_id, agent_name, room_id, workspace_url, credentials_path }`
on stdout — never the API key or the link token — while the browser URL and
user code go to stderr so a human can still complete the confirmation.
`--project-name` overrides the detected project and suggested Room name;
unless `--workspace-name` is also given, it becomes the workspace name too.
`--workspace-name` and `--agent-name` override those detected names,
`--cwd <dir>` detects somewhere other than the working directory, `--no-start`
connects without starting the runtime, and `--no-modify-path` leaves shell
profiles untouched.

The dist-tag tracks the environment: production uses `@latest`, dev uses
`@next` (newest prerelease). To pin a specific build, use `kylon-cli@X.Y.Z`.

Requirements: macOS, Linux, or Windows. The hosted `install.sh` needs no
preinstalled Node.js; the Windows `install.ps1` and the `npx` spellings need
Node.js 22.15.0+ (npm ships with Node).

### One managed `kylon` for humans and agents

The bootstrap commands (`agent link` and `auth login`) pin the CLI under
`~/.kylon/bin`: the exact bundle the daemon and its agents execute, exposed as
the `kylon` command. After the bootstrap they offer to add that directory to
your shell PATH (a marker-wrapped `. "$HOME/.kylon/env"` line in your shell rc,
or a fish `conf.d` drop-in; decline with `--no-modify-path`). From then on the
human terminal, the agents, and the daemon all run the same file — one
artifact, one version, one upgrade.

A leftover npm-global or npx-cached copy stays harmless: when it starts and
finds a strictly newer pinned install, it defers to it automatically
(installer commands — `agent …` and `gateway …` — always run as invoked, so a
fresh `npx` can still install itself over an older pinned copy; set
`KYLON_PINNED_TRAMPOLINE=0` to disable the deferral).

### Upgrading a local runtime

Automatic Kylon CLI updates are enabled by default for each enrolled computer.
The server checks an online computer for an eligible update at most once every
four hours. When it rolls an exact published version out to that computer, the
daemon uses the same drain-restart path as a manual upgrade: it waits for active
agent work to finish, installs the managed bundle under `~/.kylon/bin`, and
restarts onto it. The server never requests `--force` automatically.

The owner can change the setting under **Settings → Developer tools → Kylon
CLI → Authorized devices**, or from that computer:

```bash
kylon gateway auto-update status
kylon gateway auto-update on
kylon gateway auto-update off
```

The setting controls future automatic requests only. Turning it off does not
cancel an upgrade whose drain has already started, and manual upgrades remain
available.

To update manually, rerun the hosted install script — the same command that
installed Kylon:

```bash
curl -fsSL https://api.kylon.io/install.sh | sh
```

(`https://api.purework.ai/install.sh` on dev; Windows:
`powershell -c "irm https://api.kylon.io/install.ps1 | iex"`.) On a machine
that already has Kylon, `install.sh` first verifies the managed bundle. One
that does not answer `--version` with `kylon <version>`, or answers another
version than its sidecar records, is replaced with the release the script
pins unless another installation holds the installation lock, and the
damaged copy stays beside it as `kylon-bundle.mjs.broken-<time>`. A bundle
that answers is never overwritten, even without a readable sidecar, which is
how the CLI's own rollback leaves it (`install.ps1` never overwrites the
bundle). The script also repairs the environment around it — a vanished
Node.js gets the private runtime, the launcher and PATH snippet are
rewritten, the serving deployment is re-recorded — and then asks the
installed CLI to update itself with `kylon upgrade`. This is the command the
CLI's update notice, `kylon gateway status`, the unknown-command hint, and the
workspace's update surfaces all print; each spells it for the deployment the
machine was set up against.

`kylon upgrade` is the engine underneath the script, and can be run on its
own when the environment is known to be healthy. It resolves the newest build
on the channel this installation tracks (`latest` in production, `next` on
dev), compares it with the **installed** bundle's recorded version, and picks
the owner for the host's layout: on a gateway host the drained service
upgrade described below, on a credential-only host the daemon-guarded
self-pin, and on a host with only an npm global the `npm install -g` hint
(that copy stays the operator's own). When it is already the resolved target
— `npx --yes kylon-cli@latest upgrade` runs the newest copy — it installs
in-process rather than downloading itself a second time. `--force` skips the
drain (see the interrupts below).

The mechanism underneath is `gateway service upgrade`:

```bash
npx --yes kylon-cli@<exact version> gateway service upgrade
```

It installs the running copy's *own* bundle under `~/.kylon/bin` and
drain-restarts the daemon onto it, moving the daemon and the pinned agent
`kylon` in lockstep — so it must be run by the target version, which is why
it is spelled through `npx` with an exact version. Reach for it directly only
when an exact version matters; the workspace's update notice, the remote
upgrade button, and automatic updates all resolve to it with the exact version
they want. `npm install -g` alone updates the operator's terminal binary and
leaves the runtime service on the old build. `kylon gateway service repair`
is the same reconciliation under its recovery-oriented name.

`repair` goes one step further than `upgrade`: after reconciling the Kylon
side it installs any provider CLI this machine's placements need but do not
have, so the commonest broken placement — a Codex agent on a host with no
`codex` — is fixed by the command whose name says it fixes things. The
boundary is deliberate. It installs the npm globals this product already tells
people to install (`@openai/codex`, `@anthropic-ai/claude-code`), echoing each
command before it runs, and it does nothing else on the operator's behalf: it
never runs a preset's third-party installer script, never removes a `kylon`
install this product did not create, and never re-registers an agent. Those
stay reported findings with a command to run deliberately. Pass
`--no-provider-install` to reconcile Kylon only.

Nothing installs a provider CLI in the background. A daemon that finds its
provider missing reports it and waits — installing software on someone's
machine is something they ask for, not something a health check decides.

Codex normally uses the desktop app's current executable when installed. To
select a specific installation, set `KYLON_CODEX_BINARY_PATH` to its absolute
executable path before connecting or repairing the gateway service. The service
captures this selection for health checks and agent turns. A missing or invalid
path fails instead of switching installations. Use the same path with
`kylon provider update codex --binary-path <path>` when updating that installation.

The drain waits up to five minutes for in-flight agent work, and a drain that
exhausts its window rolls the upgrade back — so a persistently busy host would
never upgrade without an operator interrupt. Two are available:

- `kylon upgrade --force` (or `kylon gateway service upgrade --force`) skips
  the drain, or escalates one already in progress: in-flight assignments are aborted with the same
  recovery semantics as a daemon crash (the durable inbox re-drives
  interrupted work on the restarted daemon), and the new version activates
  immediately.
- `kylon gateway service cancel` abandons an in-progress upgrade: the daemon
  rolls back to the previous bundle and resumes accepting work on the old
  version.

A request or staged bundle that nobody is honoring does not need an operator:
`gateway service upgrade` refuses only a *fresh* one ("already in progress",
reported with reason `upgrade_in_progress`). Past one drain budget with no
daemon alive, or two drain budgets with one alive (the daemon itself rolls back
at the first), the marker is treated as abandoned — the previous bundle is
restored if it still exists, the marker is removed, and the upgrade starts over.
This is what lets a machine whose earlier upgrade died mid-drain pick up the
next automatic attempt instead of being refused every four hours.

### Local development (contributors)

```bash
pnpm install
pnpm --filter kylon-cli build
```

See [Development → Exposing `kylon` to provider subprocesses](#exposing-kylon-to-provider-subprocesses)
for the debugger-friendly tsx-based dev loop.

### Release channels

npm dist-tags remain the publication pointer. A separate server runtime-config
policy (`cli_auto_update/latest` and `cli_auto_update/next`) selects an exact
currently published target plus a 0-100% stable per-computer rollout for
automatic updates. A missing, disabled, mismatched, or 0% policy sends no
automatic request; manual upgrades still resolve the dist-tag normally.

Qualifying merges to `develop` publish prereleases to `next`
(`.github/workflows/cli-publish.yml`). Stable publication is optional: request
`publish_cli=true` on a production Deploy from `main`, or label its merged main
PR `release:cli`. After the Deploy finishes successfully, a separate workflow
runs fresh full CLI qualification and publishes the exact package version to
`latest`. A standalone stable dispatch runs from current `main` and requires
already-deployed services. Bump the package version before a stable release.

Stable tags are release records, not publication triggers. Do not run
`npm publish` ad hoc: both stable entry points use CI and its OIDC publisher.
Development installs `@next` and production installs `@latest`, so each
environment tracks its own release train.

#### Auto-update policy: dev is automatic, production is manual

The two `cli_auto_update` keys are maintained by deliberately different
mechanisms.

**`cli_auto_update/next` (dev) is reconciled automatically.** After a `develop`
prerelease is published, the `sync-dev-auto-update` job in
`.github/workflows/cli-publish.yml` sets the dev entry to the exact version it
just released, with `enabled: true` and `rolloutPercentage: 100`. A staged
rollout on dev would serve no purpose: the prerelease it points at is the only
build `@next` resolves to, so anyone tracking `next` is getting it regardless.

**Any CLI publish workflow run on `develop` converges the dev policy with the
real `@next`** — not only a run that published something. The job runs in one
of three modes, reported by the classifier as `sync_reason`:

| `sync_reason` | What happened | What the sync does |
| --- | --- | --- |
| `published` | this run released a prerelease | point the entry at it |
| `this_run_already_published` | a full re-run whose own version is already on npm | re-run the outstanding reconciliation |
| `ordinary_dedup_reconcile_current_next` | the bundle is identical to what `@next` already carries, so nothing was published | reconcile the entry toward the version `@next` already serves |

The third mode is the one to understand: **when there is no new bundle, the run
only bootstraps or repairs the config.** It publishes nothing, mints no
version, never touches a dist-tag, and writes no revision at all when the entry
is already correct. The version it converges on is never hypothetical — it is
read from the registry, must be an exact `X.Y.Z-next.N`, and is the build every
`@next` install is already getting.

That mode exists because the previous behaviour had a bootstrap gap. The merge
that shipped this sync (#6692) changed no CLI bundle, so content dedup skipped,
the sync job's condition rejected an ordinary skip, and the dev
`cli_auto_update/next` entry — which did not exist yet — was never created. An
identical bundle is a reason not to publish; it is not a reason to leave the
dev policy unreconciled.

The job verifies that `kylon-cli@next` actually resolves to the published
version before writing (retrying for registry read lag), and writes through
`upsertRuntimeConfigEntry`, so the same schema validation and
`runtime_config_entry_revisions` audit row apply as for an admin edit. The
revision's change reason records the published version, commit and workflow run.

The write is fenced with the entry version the job read, so it is a
compare-and-swap rather than a blind overwrite. That matters because
`cli-publish.yml` deliberately gives every run its own concurrency group: two
`develop` prereleases can be in flight at once and both reach this reconciler.
The rule is **latest wins** — the highest `X.Y.Z-next.N` the job can observe,
whether on the dist-tag or already stored in the entry, owns the target. An
older run that sees a newer one records a `superseded` no-op and succeeds; if
its fenced write loses the race instead, it re-reads both the dist-tag and the
row and re-decides against the state that won. An older release can therefore
never overwrite a newer one, and the entry never flaps between two concurrent
runs.

**The dist-tag is part of the same convergence, not an input to trust.**
`npm publish --tag next` moves the tag by wall clock, not by version, so two
overlapping runs that finish in reverse order leave the registry serving the
*older* build: run 811 publishes, then run 810 publishes and takes `@next`.
That is user-visible — `automatic-cli-update.ts` refuses to upgrade a machine
whose configured target differs from the dist-tag, logging `release_mismatch` —
so the two surfaces have to agree on one canonical winner: the newest
`X.Y.Z-next.N` any run can observe on its own release, on the tag, or in the
row.

Two mechanisms keep them agreeing:

- **The publish never moves `@next` backwards.** Immediately before publishing,
  the run re-reads the dist-tag; if it already serves a strictly newer
  prerelease, this run is already superseded and publishes under the
  non-promoting `next-superseded` tag instead. The version is still published
  and still installable by exact version — it just does not take the channel
  head. A lookup that cannot be answered stops the run *before* the
  irreversible step rather than publishing blind.
- **The sync repairs what is left.** A check-then-publish window remains, so if
  the sync job finds `@next` behind the canonical winner it moves the tag
  first — under a re-read fence, so an older run can never pull it back — and
  only then writes the row. The row is never pointed at a version the dist-tag
  does not serve, because that state upgrades nobody.

  Moving a dist-tag needs a credential: npm's OIDC trusted publishing
  authenticates `npm publish` and nothing else ([npm/cli#8547](https://github.com/npm/cli/issues/8547)).
  The sync job reads an optional `NPM_DIST_TAG_TOKEN` from its `dev`
  environment; when it is absent, the run fails with an `::error::` naming the
  exact `npm dist-tag add kylon-cli@<winner> next` to run, instead of reporting
  a convergence that did not happen.

Propagation is not part of the write's success condition. Committing the entry
also bumps a per-namespace revision counter and publishes a cache-invalidation
message on Redis, but no runtime reader polls that counter: services drop their
in-process runtime-config snapshot when the pub/sub message arrives, and
otherwise when the snapshot ages past its five-minute TTL. The publish is
bounded inside `invalidateRuntimeConfig`, so an unreachable Redis (the CI job
tunnels Postgres only) costs at most that five minutes of staleness and cannot
stall or fail an already-committed, already-audited write.

**`cli_auto_update/latest` (production) is never touched by automation.** The
stable target version and its rollout percentage are set by a human in the
admin runtime config, and ramping 0 → 100% is an explicit blast-radius
decision. Publishing a stable build to `@latest` does not enrol any computer in
updating to it; that remains a separate, deliberate step.

Two consequences worth knowing:

- **A dedup-skipped prerelease publishes nothing, but still reconciles.** When
  content dedup decides the bundle is identical to what `@next` already has, no
  version is published — and the sync job runs anyway, against the version
  `@next` currently serves. Usually that is a no-op that writes no revision;
  when the entry is missing or stale it is repaired on the spot. The sync never
  fabricates a version for a release that did not happen: the only version it
  can write is one it read off the registry.

  A run with no release of its own also never moves the dist-tag. If it finds
  the row pointing at something newer than `@next`, that winner belongs to the
  run that published it, and that run converges both surfaces itself — so this
  one records a `superseded` no-op instead of racing it. For the same reason a
  registry it cannot read — or one serving a version this workflow does not
  own — is a `::warning::` and a green run here, not a red one, and that holds
  for **every** registry read the job takes: the read that picks the target and
  the read the reconciliation itself takes just before it writes. Nothing was
  published, nothing was written, nothing is at risk, and the next push
  reconciles again. The downgrade stops there: a schema rejection, a lost CAS
  fence or a database error still fails the job on this trigger too.
- **A failed sync fails the run, loudly, and re-running repairs it.** The npm
  publish is irreversible, so the sync cannot be retried by re-publishing. If
  the config write fails (or `@next` does not converge on the published
  version), the workflow fails with an `::error::` naming the manual fix — a red
  run, never a silent partial release.

  "Re-run all jobs" is the supported repair. A re-run keeps the same run number
  and therefore mints the same `X.Y.Z-next.<run>` version, which is already on
  npm; the publish job detects exactly that case and marks the run
  `reconcile_only`, so it publishes nothing but still runs the sync job. The
  reconciliation is idempotent and reads the live dist-tag, so it either repairs
  the stale entry, finds it already correct, or finds that a newer prerelease
  has superseded this one and leaves the newer target alone. That stays distinct
  from an ordinary content-dedup skip: both start a sync, but only the re-run
  has a release of its own to reconcile, so only it may claim one. If the re-run
  also fails, set `cli_auto_update/next` in the dev admin runtime config by
  hand.

  The classifier that tells those two skips apart is
  `scripts/ci/cli-prerelease-npm.sh` — it emits `sync_reason`, and keeps
  `reconcile_only` reserved for the re-run case — and every registry lookup in
  it retries and fails closed. A transient `npm view` error is not evidence that a version
  is unpublished; treating it as such is what would let a failed reconciliation
  hide behind a green re-run. The dist-tag's own version is used as a second,
  independent confirmation of the same fact.

## Usage

### Sign in for workspace commands

For a person using `kylon workspace ...` from their own terminal, open the
workspace's **Settings → Kylon CLI** section, expand it, and copy its setup
command, or run:

```bash
npx --yes kylon-cli@latest auth login --workspace <WORKSPACE_ID>
```

(or, once `kylon` is installed, just `kylon login` — the browser page then asks
which workspace to authorize). The CLI opens Kylon in your browser. After you
sign in, confirm the installation and workspace shown on the authorization
page, and verify that its confirmation code matches the one printed in your
terminal. The browser approves a short-lived
request but never receives the credential. The CLI proves possession of its PKCE
verifier while polling Kylon over HTTPS, receives the credential directly from
the API, and saves it in the versioned credential collection at
`~/.kylon/workspace-auth.json` with mode `0600`. No loopback listener, incoming
port, or browser request to localhost is used. On success the CLI also pins
itself under `~/.kylon/bin` and offers to put that directory on your PATH, so
subsequent commands are plain `kylon workspace ...` with no npx.
The collection keeps credentials separately by server and workspace, and
`--scope-workspace` selects the matching entry.

App source checkouts configure a Git credential helper automatically. After
`kylon workspace app checkout`, ordinary `git push origin draft/<slug>` uses
the current credential without a manual token export. Environment credentials
(including `KYLON_GIT_TOKEN`) take precedence; human CLI checkouts can fall back
to the saved credential matching the checkout's API server and workspace.
The helper reads the current file on every request, so login rotation takes
effect without re-exporting a key. The default file is
`~/.kylon/workspace-auth.json`; with `XDG_CONFIG_HOME` set it is
`$XDG_CONFIG_HOME/kylon/workspace-auth.json`. Kylon Agent runtimes and
Agent-created checkouts never fall back to the operator's saved identity.
Credentials are returned only for the exact checkout remote, never written
into Git configuration. Re-run checkout from its non-Git parent directory to
upgrade an existing checkout's helper.

Each installation credential expires after 90 days. Re-running `kylon auth
login` for the same installation and workspace rotates that credential, making
the previous value invalid. Use `kylon status` to inspect the active user,
workspace name and ID, workspace role, credential source, and expiration time.
The active saved credential supplies the workspace automatically, so no
workspace ID is required. `kylon auth status` is an equivalent alias. Both
forms accept `--json` for machine-readable output. Status verifies and enriches
the locally stored identity against the API when available; if the API cannot
be reached, it retains the cached IDs and reports that remote details are
unavailable.

Browser authorization includes the API origin in the saved workspace profile,
so workspace commands do not require `--server-url` again. API keys are
write-only Connections with explicit agent grants. Create one by asking the
workspace's Kylon agent to start the secure Connection setup flow;
enter the Connection name, key, value, and optional icon in the app. The
workspace CLI lists each granted service's variable names and injects one
service's variables into a child command:

```bash
kylon workspace connection list --toolkit custom-api-key --scope-workspace <WORKSPACE_ID>
kylon workspace connection run --connection <CONNECTION_ID> -- curl https://api.example.com/resource
```

Use `kylon workspace connection list|create|credential set|access request|run`
for API-key Connections. There is no secret command any more:

- There is intentionally no top-level `kylon secret` command.
- The `kylon workspace secret` noun is retired: every verb only prints its
  Connection replacement, accepts no secret value, and changes nothing.
- `kylon gateway secret` is retired too: an agent keeps no secrets of its
  own, so `list`, `set` and `delete` make no request and only print the
  Connection command that replaced them. A credential is stored as a Custom
  API Service from the agent's setup card or from Connections in Kylon, the
  agent reads it from its environment, and the person who manages the
  service removes it.

```bash
kylon auth logout --workspace <WORKSPACE_ID>
```

Logout revokes the selected installation credential remotely before removing
that entry from the local collection. With no `--workspace`, it selects the most
recently authorized entry. If Kylon cannot confirm revocation, it keeps the local
credential so you can retry. `kylon auth logout --local-only` deliberately skips
the remote revocation. This logout is deliberately credential-only: it does not
disconnect the local agent runtime or change connected agents. If that installation
still runs external agents, it remains listed as an **Authorized device** so its
runtime access can still be removed without signing the CLI in again.

You can instead remove an **Authorized device** from **Settings → Kylon CLI**.
After warning about the impact, that workspace-scoped action revokes any active
installation credential, removes the local runtime access associated with the
same installation, and disconnects every external agent using it. The device's
authorizations and runtime access in other workspaces, browser
sessions, and workspace service keys are unaffected.

Credentials created by the earlier browser flow appear as **Legacy user API
key** in Settings. They can be revoked there, but they are not bound to a single
workspace; sign in again to replace one with the per-installation flow.

### Run

`gateway run` starts the local runtime service from this environment's saved
connection. It is the command the installed `launchd` / `systemd --user`
service execs, and the child the Windows `gateway supervise` loop keeps
running; run it manually to keep connected agents available in the foreground.

```bash
kylon gateway run
```

It takes no connection flags: link an agent first with `kylon agent link`.
Without a saved runtime connection it exits with guidance pointing there.

### Sleep, wake, and keep-awake (macOS and Windows)

By default the daemon requests idle sleep prevention whenever it runs: macOS
uses `caffeinate`; Windows uses a hidden helper tied to the daemon's lifetime.
The display can turn off while agents remain available. Sleep prevention is
only requested on AC power; Windows checks for battery transitions every second.
Battery, lid-close, and manual sleep policy still take precedence. No effect on Linux.

On Windows, the hidden scheduled-task launcher retries a failed supervisor three times at one-minute
intervals. A normal exit with no saved registration stays stopped. This does not
run while the user is signed out, wake a sleeping computer, or recover every
explicit Task Scheduler stop. Updated task definitions take effect on the next
task start; an already running supervisor keeps its original code until restarted.

```bash
kylon keep-awake            # show the current mode
kylon keep-awake while-busy # prevent sleep only while assignments run
kylon keep-awake off        # never prevent sleep
```

Modes: `always` (default), `while-busy`, `off`. The setting persists in
`~/.kylon/gateway-settings.json`; a running daemon hot-applies changes within
seconds, no service restart required.

When the machine does sleep (battery, lid closed, manual sleep), assignments
dispatched to its agents queue server-side. The daemon detects the wake
instantly (a wall-clock jump across its monitor tick) and recovers in one
pass: it force-reconnects the runtime event stream with reset backoff,
re-asserts presence on the fresh connection, and claims the queued work —
instead of waiting out inactivity timeouts and heartbeat intervals.

### Commands

| Command | Description |
|---|---|
| `kylon agent link --url <link> [-- <launch command>]` | **Recommended.** Connect one agent and start its local runtime. ACP launch commands are saved in the same operation. |
| `kylon disconnect` | Forget this environment's saved runtime connection. Local only: workspace-side agent configuration is unchanged. |
| `kylon gateway resume` | Resume this computer after inactivity using its owner's saved workspace login. |
| `kylon gateway run` | Run the local runtime service from the saved connection (service entrypoint). |
| `kylon keep-awake [mode]` | Show or set macOS/Windows sleep prevention (`always` (default) / `while-busy` / `off`). |

### Supported Providers

- `codex` — OpenAI Codex CLI
- `claude-code` — Anthropic Claude Code CLI
- `grok-build` — Grok Build over ACP. Uses the explicitly installed
  `grok agent stdio`; Kylon does not download or execute Grok implicitly during
  a readiness probe or assignment. Provider authentication and model selection
  remain in Grok's local configuration.
- `hermes` — Hermes over ACP, using `hermes-acp` or `hermes acp`.
- `openclaw` — OpenClaw CLI using `openclaw agent --message <prompt> --json`.
  A message too large for the command line is delivered as a file via
  `--message-file <path>` instead (requires OpenClaw 2026.6.11 or newer; the
  OpenClaw CLI has no stdin message channel).
- `generic` - provider-neutral wrapper. Runs a `kylon-provider`
  executable on `PATH` and expects newline-delimited JSON events matching
  `docs/journal_docs/05_25_external_agent_provider_adapter_contract.md`.
  Delivery: `--prompt <text> --workdir <dir> [--system-prompt <text>]
  [--resume <id>]`. When the payload is too large for the platform's
  command-line budget (cmd.exe caps its input line at 8,191 chars; Linux caps
  one argv string at 128 KiB), the gateway instead writes the payloads to
  owner-only temp files and passes `--prompt-file <path>`
  (`--system-prompt-file <path>` for the system prompt), with the same paths
  exported as `KYLON_PROMPT_FILE`/`KYLON_SYSTEM_PROMPT_FILE`. File delivery is
  used only when the wrapper opts in by advertising
  `kylon-provider-caps: prompt-file, system-prompt-file` anywhere in its
  `--version` output (the one probe every wrapper already supports); a wrapper
  without the advertisement fails over-budget assignments with a named error
  instead of receiving flags it would misparse.

## macOS startup logs and external config volumes

The macOS service writes startup stdout and stderr to
`~/Library/Logs/KylonGateway/launchd.stdout.log` and `launchd.stderr.log`.
These paths are independent of `~/.kylon` and `XDG_CONFIG_HOME`: launchd must
open its output files before Node can request access to a removable volume.
Install, upgrade, and repair use the same paths and prepare the log directory
with mode `0700` and files with `0600`.
Oversized startup files rotate at service installation/repair (10 MiB, three
files per stream). Existing daemon logs are retained at `<configDir>/gateway.log`.
Node and provider tools may still need macOS permission to access external data.

`kylon gateway status` shows both locations, including when the daemon could
not start. Its JSON keeps `daemon.log_path` for compatibility and adds
`daemon.startup_log_paths` on macOS. Upgrade failure guidance reads recent
errors from both daemon and startup stderr logs.

`kylon diagnose` and its upload collect both kinds of logs. The same collector
serves server-requested error diagnostics; self-diagnosis also sees the current
startup tails. Raw startup output is redacted at collection time, leaf symlinks
are not followed, and startup tails are capped at 1 MiB per file (256 KiB for a
scoped error bundle). Missing logs do not prevent collecting other evidence.
Full bundles keep three startup files per stream; scoped bundles keep two.
Linux and Windows retain their existing log paths.

## Remote diagnostics

The CLI reports to the server through one channel (`src/lib/telemetry.ts`):
every logger record passes through it after redaction, and what leaves the
machine depends on the identity the running operation selected. This is event
logging into the API-to-Grafana Loki pipeline (`service=cli-client`), not
OpenTelemetry/Tempo tracing. It never ships Grafana credentials and never falls
back to another saved identity.

- **Machine identity** (the computer daemon and its supervisor, locked by the
  computer session): posts to `POST /workspaces/:ws/computers/:id/client-events`
  every `warn`/`error` record, the info-level names on the shared inventory, and
  the daemon lifecycle events (`daemon.started`, `daemon.crash_detected`,
  `daemon.system_wake`, `daemon.shutdown`). Fields are flattened one level and
  bounded (32 keys, 300 characters); a prose message is normalized to a
  snake_case name with the wording kept in `text`. The server stamps
  `p2EventType=cli_daemon_event` and the machine's CLI version and OS, holds
  each machine to 300 events per 5 minutes, and announces what it dropped or
  rejected. The operator's `remoteDiagnostics` gateway setting is the consent
  for this path, read at every flush.
- **User identity** (any other command once it has a credential): posts to
  `POST /client-logs/cli` under the event and field allowlists in
  `@p2/types/cli-telemetry`, so a command never uploads paths, prompts, argv,
  or arbitrary error text. Identity and workspace attribution come from server
  authentication, not client fields.
- **Anonymous** (status (`status`/`auth status`, `gateway status`), `diagnose`,
  the upgrade commands (`upgrade`, `provider update`, `gateway service`)): the
  same URL without a credential, command outcomes only, with an even narrower
  metadata allowlist. The setup commands (`auth login`, `agent link`, `connect`,
  `onboard`) report anonymously only when they fail, with the setup session id
  from the link inspection and the stage they reached, and switch to the
  credential they obtain. Other commands never fall back to anonymous
  submission when authentication fails. An anonymous report goes to
  `--server-url` when given; without it, `agent link` reports to the server its
  link names, and the other anonymous commands to the default server (the
  server env vars, then the URL the install script recorded, then production).

Telemetry initialization calls the installation store's `ensure()`:
`install.json` in the CLI configuration directory holds the random `installId`,
sent as `install_id` on every record. It is created before login and reused
across runs; deleting the file resets it, copying the configuration can
duplicate it. It identifies an installation, not a device or a person, so these
are pseudonymous diagnostics. If the installation cannot be read or created,
records go out without `install_id`; anonymous ones require it and stay local.
An entry that cannot be read, is not a regular file, or does not hold a valid
`cli_…` id counts as damaged and is never replaced, because a saved computer
connection records the id. Commands that need it (`agent link`, `connect`,
`onboard`, `login`) stop, name the file, and print commands that first rename
the entry aside (which never follows a link), then restore the recorded id or
start over. A link to a valid file is read through, never written.

Set `KYLON_TELEMETRY_DISABLED=1` in the CLI/daemon process environment to turn
the whole channel off; local diagnostic logs are unchanged. Restart a running
daemon after changing its environment.

Delivery: a bounded queue of 200 records (oldest dropped first, the count
announced as `gateway.remote_events.dropped_locally`), one batch of up to 20
every five seconds, plus an immediate flush for the daemon lifecycle events. A
`401`, `403`, or `404` stops the channel for the rest of the process; any other
failure keeps the batch and backs off, doubling from 30 seconds to 5 minutes.
Requests do not follow redirects; a command's request is cut after 2.5 seconds
(a cold connection to the API takes 0.5–0.7 s, and a failed command uploads
at exit with no connection to reuse), the daemon's after 5 seconds. A
`cli.command_failed` record starts its upload at once rather than at the
next interval. Normal command completion flushes the latest batch;
hard kills can lose events. The API limits each user identity to 60 batches per
minute and 32 KiB per batch, anonymous sources to 20 batches per minute per
hashed IP.

### Event inventory

Info-level names are the shared inventory in `@p2/types/cli-telemetry`:
command lifecycle (`cli.command.started`, `cli.command.completed`,
`cli.command_failed`, `cli.api.failed`), connection open/close, gateway
connection failures and reconnect scheduling, assignment receipt and
acceptance, provider execution, cancellation, result delivery and outbox
replay, supervisor lifecycle, and upgrade outcomes. A machine identity adds
every warn/error record and the daemon lifecycle; a user identity is limited to
the inventory on both ends.

## State Model

The CLI uses a per-agent installation profile and three runtime-state layers:

- **InstalledAgentProfile** — non-secret agent identity, provider, and exclusive workdir ownership
- **GatewaySession** — authenticated connection to the P2 server for one agent
- **LogicalSessionState** — per-`(gateway session, agent)` binding holding the current workdir and provider
- **ProviderRuntimeEntry** — per-conversation provider resume cache, keyed by `(gateway session, channel, agent, scope, provider, workdir)` (disposable)

Switching workdir updates the logical session without creating a new one. Provider runtimes are cached per workdir + conversation scope — switching back resumes the old runtime.

Agent state is persisted to `~/.kylon/agents/<agent-id>/` (or
`$XDG_CONFIG_HOME/kylon/agents/<agent-id>/`). Human workspace authentication
remains in the top-level Kylon config directory.

## Development

> This section assumes you cloned `fre-so/p2` and ran `pnpm install` at the
> repo root. All commands are run from anywhere in the monorepo unless
> otherwise noted.

### Inner loop

```bash
# type-check without emitting
pnpm --filter kylon-cli typecheck

# tsc build — emits dist/bin/kylon.js and other .js files
pnpm --filter kylon-cli build

# unit tests (no network, no DB)
pnpm --filter kylon-cli test

# run the locally built CLI
node packages/cli/dist/bin/kylon.js --help
```

The Web agent-settings "Local dev" block generates the same
`node packages/cli/dist/bin/kylon.js …` invocation from the logged-in
agent's API key. If you change `src/bin/kylon.ts` or anything it
imports, rerun `pnpm --filter kylon-cli build` before re-executing.

### Exposing `kylon` to provider subprocesses

`node packages/cli/dist/bin/kylon.js gateway run …` starts the daemon
but leaves **no `kylon` binary on PATH**. When the provider subprocess
(claude-code / codex) then tries `kylon workspace …` via its Bash tool,
the shell fails with `command not found`. Two ways to fix this:

**Option 1 — `pnpm link` (persistent).** Symlink kylon's published
`bin.kylon` into pnpm's global bin dir:

```bash
pnpm --filter kylon-cli bundle            # or bundle:minify for a prod-shaped build
pnpm --filter kylon-cli link --global

which kylon
# → ~/Library/pnpm/kylon (or similar) → packages/cli/dist/kylon-bundle.mjs
```

From here on, start the daemon via the linked binary instead of the
raw `node dist/bin/kylon.js`:

```bash
kylon gateway run --server-url http://localhost:5173/api --provider codex --api-key pak_…
```

Every provider call to `kylon workspace …` resolves to the linked
binary. Edit source → `pnpm --filter kylon-cli bundle` → next provider
call picks it up (each workspace invocation is a fresh process;
restart the daemon only for *daemon*-side edits). Clean up with
`pnpm --filter kylon-cli unlink --global`.

**Option 2 — `--dev-cli-shim` (ephemeral, IDE-friendly).** The daemon
can install a temporary bash shim that execs the TS source through
tsx. Pass `--dev-cli-shim <abs-path-to-p2-repo>` on `gateway run` or
`gateway start`:

```bash
node packages/cli/dist/bin/kylon.js gateway run \
  --server-url http://localhost:5173/api \
  --provider codex \
  --api-key pak_… \
  --dev-cli-shim "$(pwd)"
```

The daemon prints the shim location on startup:

```text
[dev] kylon shim: /tmp/kylon-dev-shim-abc123/kylon
[dev] provider calls will exec: node --import tsx /abs/path/packages/cli/src/bin/kylon.ts
```

The tmpdir is prepended to the daemon's `PATH`, so the provider
subprocess (and the bash shell it spawns) resolves `kylon` to the
shim. The shim execs `node --import tsx <src>`, so:

- Every `kylon workspace …` invocation reads the current `src/*.ts` —
  no bundle rebuild needed between edits.
- A Node debugger attached to the daemon is inherited by each shim
  invocation (they exec `node`, so `NODE_OPTIONS` and VS Code's
  Auto-Attach loader pass through).
- On SIGINT/SIGTERM the tmpdir is wiped.

This flag is **only compiled into local (non-minified) builds**. The
npm package and any `bundle:release` output reject `--dev-cli-shim` as
an unknown argument and omit it from `--help`, so it can never
accidentally ship.

### Debugging both the daemon and `kylon workspace` calls

Combine `--dev-cli-shim` with a Node debugger to step through the
full chain — daemon → provider subprocess → `kylon workspace …` — in
one IDE session.

**VS Code**:

1. Enable `Debug: Toggle Auto Attach → Always` (or `Only With Flag`).
   VS Code prepends its `js-debug` bootloader to `NODE_OPTIONS`, which
   every child Node process — including the ones launched by the
   shim — inherits.
2. Open an integrated terminal and run:

   ```bash
   node packages/cli/dist/bin/kylon.js gateway run \
     --server-url http://localhost:5173/api \
     --provider codex \
     --api-key pak_… \
     --dev-cli-shim "$(pwd)"
   ```

3. Set breakpoints in both `packages/cli/src/commands/gateway-start.ts`
   (daemon) and `packages/cli/src/commands/workspace/*.ts` (child
   commands). Both fire the next time the provider issues a workspace
   call.

**JetBrains / others**: export `NODE_OPTIONS=--inspect=0.0.0.0:0`
before launching the daemon. Every subsequent Node process — daemon
and every `kylon workspace …` invocation — opens its own inspector
port. Attach your IDE to the process list.

No debugger attach? The shim still works — source edits are picked up
on the next provider call, but breakpoints just don't fire.

### Bundles

`scripts/bundle.mjs` builds two single-file ESM bundles from this package,
each with its esbuild metafile beside it (`<bundle>.meta.json`, not
published):

- `dist/kylon-bundle.mjs`, the human CLI (`src/bin/kylon.ts`) and the
  package's one bin, `kylon`;
- `dist/kylon-core-bundle.mjs`, the core bundle (`src/bin/kylon-core.ts`):
  an agent's commands (`workspace`, `mcp serve`, `gateway attach`, the App
  checkout's git credential helper) and the Kylon app's `desktop` onboarding
  protocol. It contains none of the login, link, connect, service, update or
  pinning modules, nor the readers of the saved login and the legacy gateway
  session, and answers every other command as not available in this build.
  `scripts/bundle-guard.mjs` reads both metafiles at the end of every build
  and fails it when one of those modules appears in the core bundle.

Three variants, each building both bundles:

| Script | Output | Passes to `bundle.mjs` | Use when |
|---|---|---|---|
| `pnpm --filter kylon-cli bundle` | `dist/kylon-bundle.mjs`, `dist/kylon-core-bundle.mjs` | _(none)_ | debugging the bundled shape while keeping readable names — not shipped |
| `pnpm --filter kylon-cli bundle:minify` | `dist/kylon-bundle.mjs`, `dist/kylon-core-bundle.mjs` | `--minify` | reproducing the pre-obfuscation size and behavior for a bisect |
| `pnpm --filter kylon-cli bundle:release` | `dist/kylon-bundle.mjs`, `dist/kylon-core-bundle.mjs` | `--minify --obfuscate` | what ships on npm |

The `bundle:release` path runs esbuild with `--minify`, then passes the
output through `javascript-obfuscator`. It's also what the `prepack` hook
runs, so `pnpm pack` / `npm publish` always produce the obfuscated shape
even if you forget to call `bundle:release` explicitly.

Run the bundle directly to sanity-check it:

```bash
pnpm --filter kylon-cli bundle:release
node packages/cli/dist/kylon-bundle.mjs --help
```

### Testing

Unit tests run against Node's built-in test runner (`node:test`) plus
`tsx`. They touch the filesystem inside temp dirs but never the
network or a database, so `pnpm --filter kylon-cli test` is safe to
run anywhere.

E2E tests drive the CLI as a subprocess against a configurable mock
or live server:

```bash
# headless e2e (mock provider processes spawned from scripts/mock-*.mjs)
pnpm --filter kylon-cli test:e2e

# live e2e against a real P2 environment — requires doppler secrets
doppler run --project p2 --config prd -- pnpm --filter kylon-cli test:e2e:live
```

Live E2E tests provision a throwaway workspace via the REST API, so
expect them to take several minutes and to leave audit trail rows in
the target environment. Do not point them at production casually.

Before shipping a release, also smoke-test the packaged artifact
exactly as operators will receive it:

```bash
# 1. produce the release bundle + tarball
pnpm --filter kylon-cli bundle:release
cd packages/cli && pnpm pack --pack-destination /tmp/kylon-out

# 2. install the tarball in a clean directory
WORK=$(mktemp -d) && cd "$WORK"
npm init -y >/dev/null
npm install /tmp/kylon-out/kylon-cli-*.tgz

# 3. the published shape should have only three entries
ls node_modules/kylon-cli               # dist/  package.json  README.md
ls node_modules/kylon-cli/dist          # kylon-bundle.mjs

# 4. verify the binary is runnable
node_modules/.bin/kylon --help

# 5. confirm the bundle is actually obfuscated
head -c 200 node_modules/kylon-cli/dist/kylon-bundle.mjs
# expect `#!/usr/bin/env node` followed by hexadecimal identifier soup,
# not recognizable function names or source strings
```

### Obfuscation

`bundle:release` and `prepack` run `javascript-obfuscator` with a
conservative preset chosen for runtime safety:

- **On:** `compact`, `identifierNamesGenerator: "hexadecimal"`,
  `stringArray` with `base64` encoding + rotate + shuffle, two
  wrapper function layers.
- **Off:** `controlFlowFlattening`, `deadCodeInjection`,
  `selfDefending`, `debugProtection`, `unicodeEscapeSequence`. These
  trade correctness and startup latency for marginal protection — do
  not turn them on without measuring startup and rerunning the full
  test:e2e suite.
- `renameGlobals` stays off so Node built-ins keep their names.

Startup stays under 100 ms on modern hardware; bundle grows from
~85 KB (minify only) to ~230 KB (obfuscated). Obfuscation is a
tampering and casual-reading deterrent, not a security control — the
API server is the security boundary.

## Release

The CLI ships via **npm dist-tags** — there is no server-side version policy.
`cli-verify.yml` validates on PRs and pushes; `cli-publish.yml` publishes via
OIDC (no token): a prerelease to the `next` tag on every qualifying merge to
`develop`, and an optionally requested stable release from current `main` to
`latest`, after the web/server deploy and fresh complete CLI qualification.
Development installs `@next`; production installs `@latest`.

### Versioning

Use explicit semver in `packages/cli/package.json`:

| Bump | When |
|---|---|
| patch (`0.1.0 → 0.1.1`) | bug fix, no new flags, no behavior change |
| minor (`0.1.x → 0.2.0`) | backward-compatible capability (new command, new flag) |
| major (`0.x.x → 1.0.0`) | breaking change to CLI contract or runtime behavior |

Prerelease builds are versioned `<package-version>-next.<run>` automatically by
`cli-publish.yml`. Stable mode publishes the exact package version and skips
idempotently if npm already has it. Bump `packages/cli/package.json` whenever a
new production CLI build must be published. Service deployment alone leaves
`latest` unchanged.

### Publishing

- **Prerelease (automatic):** every merge to `develop` touching the CLI publishes
  `<package-version>-next.<run>` to the `next` tag via `cli-publish.yml` (OIDC, no
  `NPM_TOKEN`). dev tracks this tag, so dev always dogfoods the newest build.
- **Stable after services (optional):** set `publish_cli=true` on a production
  `deploy.yml` dispatch from `main`, or add `release:cli` to the merged main PR.
  `cli-post-deploy.yml` waits for that Deploy's successful completion and starts
  the independent test/verify/publish task. Default service deploys skip it.
- **Stable standalone:** dispatch `cli-publish.yml` from `main` with
  `release_channel=stable`. It verifies the current main commit came through a merged main
  PR and that its service changes have deployed. CLI-only changes can follow
  the already-deployed ancestor. Both stable paths run full provider E2E and
  platform verification; prior PR CI evidence does not replace fresh proof.
- **The merged PR's preview must still match `main`.** Stable preparation
  restores the merged PR's exact preview by rerunning its last
  `pull_request` run, and that rerun is accepted only when the run's merge
  commit has the same tree as the current `main` head. The merge commit was
  computed against `main` as it stood at the PR's last push, so anything that
  lands on `main` between that push and the stable run (a hotfix, another
  release) makes the trees differ and the rerun is refused with
  `Closed previews can only be recreated by rerunning the exact production
  candidate still on main`. Nothing about the closed PR can be repaired: open
  a fresh CLI-only PR from the current `main`, merge it, and dispatch stable
  on that commit, keeping `main` still until the CLI is published.

Do not `npm publish` ad hoc: use the stable workflow and its OIDC provenance.
Pushing a version tag alone does not publish.

### Rollback

npm publishes are immutable; roll back by re-pointing the tag, not by
unpublishing:

```bash
npm dist-tag add kylon-cli@<last-good> latest   # move the channel back
npm deprecate kylon-cli@<bad> "Broken release — use <last-good>."
```

Re-pointing the tag stops the bad build from spreading: hosts that have not
upgraded yet resolve `<last-good>` on their next `kylon upgrade` or automatic
update. It does not walk a host back that already runs `<bad>` — the install's
direction guard keeps a newer installed bundle over an older invoked copy, and
`kylon upgrade` reports such a host as already current — so the way back for
those hosts is publishing a fixed, higher version. Do not `npm unpublish`.

### Server compatibility without a CLI release

Service-only releases do not run the complete provider E2E matrix. They keep
two cheaper checks in CI:

- `cli-service-compat-contract.test.ts` sends independently versioned 0.7.4
  request templates through the candidate API's real computer-key auth,
  connection fence, task leases and reply persistence. The templates in
  `scripts/ci/contracts/kylon-0.7.4.json` intentionally omit newer optional
  capability fields. Keep this compatibility floor fixed; a new required field
  must remain compatible with it rather than updating both sides of the test.
- For backend, shared, CLI, root build or unclassified changes, the reusable
  `CLI service compatibility` workflow downloads the current production stable
  CLI, checks both public installer versions against npm `latest`, freezes its
  exact version/integrity, and runs its foreground daemon against this commit's
  local API with isolated PostgreSQL/Redis. A deterministic Claude process
  supplies tool/text/result events without model calls or provider credentials.
  The workflow verifies completed task/message persistence and uploads the
  candidate SHA, package digest and executed-test report. Missing or skipped
  cases fail the existing required `Tests` context. Display-only web/admin,
  desktop/mobile, documentation and Grafana configuration changes skip this
  extra smoke; unknown paths and missing diff history run it conservatively.

The contract test also participates in normal affected-code Vitest selection.
The smoke is excluded from that suite to avoid downloading/running a second
client for every unrelated test run. Run both locally, **sequentially** (database
preparation rebuilds the worktree's isolated schema):

```sh
node scripts/ci/prepare-cli-service-compat.mjs /tmp/cli-compat-stable
CLI_COMPAT_PACKAGE_DIR=/tmp/cli-compat-stable bash scripts/test-local.sh --full -- --config scripts/ci/vitest-cli-service-compat.config.ts
```

This is a pre-merge protocol gate, not production/browser login evidence or
real-provider E2E. Direct hotfix/patch deployment outside the normal PR gate
must run `cli-service-compat.yml` manually on the target ref and check its SHA;
the workflow neither publishes nor deploys. Major protocol changes can still
request `external-agent:full`. Stable CLI publication always runs fresh full
provider/platform qualification after the service deployment, independently
of these cheap checks.

### Gemini CLI

Install stable Gemini CLI 0.58.0 or newer with
`npm install -g @google/gemini-cli@latest`, then run `gemini` interactively to
configure persistent Google sign-in or a securely stored API key. Select Gemini
CLI in Kylon and run its Connect command. Kylon launches the installed
`gemini --acp` through the shared ACP executor; the launch cannot be overridden
with `agent configure`. Older installs receive an upgrade remedy. A successful
handshake reports authentication as unverified until a real turn succeeds.

Session loading, workspace MCP tools, streamed text/tool activity and
cancellation use ACP. Kylon does not populate Gemini's global skill directories
or forward arbitrary Google credential variables from the daemon environment.
The model/effort picker, provider update command and Gemini quota display are
not available for this provider.


Project-aware onboarding in CLI 0.6.0 requires an API and browser supporting
`bootstrap_workspace_v3`. Older servers fail explicitly before context staging;
the CLI never silently removes project scope. Older CLI requests and saved
onboarding recovery records remain supported by the new API.


When this computer pauses after 14 days without real local business activity,
`kylon gateway status --json` reports its retained sleep intent. Run
`kylon gateway resume` to verify owner authorization and restart its installed
service. Reboots and system wake respect that intent. Pending task and script
results remain on disk until delivery; recovery does not relink or erase them.
